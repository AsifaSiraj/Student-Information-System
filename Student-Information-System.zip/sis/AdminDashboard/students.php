<?php
session_start();
include("../config/db.php");
if ($_SESSION['role'] != 'admin') { header("Location: ../index.html"); exit(); }

// ADD STUDENT
if (isset($_POST['add_student'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $roll = $_POST['roll_no'];
    $dept = $_POST['department_id'];
    $password = $_POST['password']; // plain password (easy way)

    $stmt = $conn->prepare("INSERT INTO students (name,email,roll_no,password,department_id) VALUES (?,?,?,?,?)");
    $stmt->bind_param("ssssi", $name,$email,$roll,$password,$dept);
    $stmt->execute();

    header("Location: students.php"); 
    exit();
}

// UPDATE STUDENT
if (isset($_POST['update_student'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $roll = $_POST['roll_no'];
    $dept = $_POST['department_id'];
    $password = $_POST['password'];

    if (!empty($password)) {
        // update with password
        $stmt = $conn->prepare("UPDATE students SET name=?, email=?, roll_no=?, password=?, department_id=? WHERE id=?");
        $stmt->bind_param("ssssii", $name,$email,$roll,$password,$dept,$id);
    } else {
        // update without changing password
        $stmt = $conn->prepare("UPDATE students SET name=?, email=?, roll_no=?, department_id=? WHERE id=?");
        $stmt->bind_param("sssii", $name,$email,$roll,$dept,$id);
    }
    $stmt->execute();

    header("Location: students.php");
    exit();
}

// DELETE STUDENT
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM students WHERE id=$id");
    header("Location: students.php");
    exit();
}

// EDIT MODE
$editData = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editData = $conn->query("SELECT * FROM students WHERE id=$id")->fetch_assoc();
}

// GET DATA
$students = $conn->query("SELECT students.*, departments.name as dept_name 
    FROM students 
    LEFT JOIN departments ON students.department_id=departments.id");
$departments = $conn->query("SELECT * FROM departments");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Students | Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css/studentsCrud.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="AdminDashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li class="active"><a href="students.php"><i class="fas fa-users"></i> Manage Students</a></li>
      <li><a href="admin_register_student_course.php"><i class="fas fa-home"></i> Register Student in Course</a></li>
      <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</a></li>
      <li><a href="courses.php"><i class="fas fa-book"></i> Manage Courses</a></li>
      <li><a href="departments.php"><i class="fas fa-building"></i> Manage Departments</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

  <div class="main-content">
    <div class="header">
      <h1><i class="fas fa-users"></i> Manage Students</h1>
      <div class="user-info">
        <span>Welcome, <?= $_SESSION['username'] ?></span>
        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username']) ?>&background=random" alt="Profile" class="profile-img">
      </div>
    </div>

    <!-- Add / Update Student Form -->
    <div class="card">
      <h2>
        <?php if($editData){ ?>
          <i class="fas fa-edit"></i> Update Student
        <?php } else { ?>
          <i class="fas fa-user-plus"></i> Add New Student
        <?php } ?>
      </h2>
      <form method="POST" class="student-form">
        <div class="form-group">
          <label for="name">Full Name</label>
          <input type="text" id="name" name="name" value="<?= $editData ? $editData['name'] : '' ?>" placeholder="Enter student full name" required>
        </div>

        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" value="<?= $editData ? $editData['email'] : '' ?>" placeholder="Enter student email" required>
        </div>

        <div class="form-group">
          <label for="roll_no">Roll Number</label>
          <input type="text" id="roll_no" name="roll_no" value="<?= $editData ? $editData['roll_no'] : '' ?>" placeholder="Enter roll number" required>
        </div>

        <div class="form-group">
          <label for="password">Password <?= $editData ? '(leave blank to keep unchanged)' : '' ?></label>
          <input type="text" id="password" name="password" value="" placeholder="Enter password">
        </div>

        <div class="form-group">
          <label for="department_id">Department</label>
          <select id="department_id" name="department_id" required>
            <option value="">Select Department</option>
            <?php
              $deptRes = $conn->query("SELECT * FROM departments");
              while($d=$deptRes->fetch_assoc()){ 
                $selected = ($editData && $editData['department_id']==$d['id']) ? "selected" : "";
                echo "<option value='{$d['id']}' $selected>{$d['name']}</option>";
              }
            ?>
          </select>
        </div>

        <?php if($editData){ ?>
          <input type="hidden" name="id" value="<?= $editData['id'] ?>">
          <button type="submit" name="update_student" class="btn btn-edit">
            <i class="fas fa-save"></i> Update Student
          </button>
          <a href="students.php" class="btn btn-primary">Cancel</a>
        <?php } else { ?>
          <button type="submit" name="add_student" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Add Student
          </button>
        <?php } ?>
      </form>
    </div>

    <!-- Student List -->
    <div class="card">
      <h2><i class="fas fa-list"></i> Student List</h2>
      <div class="table-responsive">
        <table class="styled-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Roll No</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while($s=$students->fetch_assoc()){ ?>
            <tr>
              <td><?= $s['id']?></td>
              <td><?= $s['name']?></td>
              <td><?= $s['email']?></td>
              <td><?= $s['roll_no']?></td>
              <td><?= $s['dept_name']?></td>
              <td class="actions">
                <a href="?edit=<?= $s['id']?>" class="btn btn-edit"><i class="fas fa-edit"></i> Edit</a>
                <a href="?delete=<?= $s['id']?>" class="btn btn-delete" onclick="return confirm('Delete this student?')">
                  <i class="fas fa-trash-alt"></i> Delete
                </a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
