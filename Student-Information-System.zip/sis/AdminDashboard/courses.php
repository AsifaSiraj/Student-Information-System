<?php
session_start();
include("../config/db.php");
if ($_SESSION['role'] != 'admin') { header("Location: ../index.html"); exit(); }

// ADD Course
if (isset($_POST['add_course'])) {
  $name = $_POST['name'];
  $code = $_POST['code'];
  $dept = $_POST['department_id'];
  $teacher = !empty($_POST['teacher_id']) ? $_POST['teacher_id'] : NULL;

  $stmt = $conn->prepare("INSERT INTO courses (name,code,department_id,teacher_id) VALUES (?,?,?,?)");
  $stmt->bind_param("ssii", $name,$code,$dept,$teacher);
  $stmt->execute();
  header("Location: courses.php");
  exit();
}

// UPDATE Course
if (isset($_POST['update_course'])) {
  $id = $_POST['id'];
  $name = $_POST['name'];
  $code = $_POST['code'];
  $dept = $_POST['department_id'];
  $teacher = !empty($_POST['teacher_id']) ? $_POST['teacher_id'] : NULL;

  $stmt = $conn->prepare("UPDATE courses SET name=?, code=?, department_id=?, teacher_id=? WHERE id=?");
  $stmt->bind_param("ssiii", $name,$code,$dept,$teacher,$id);
  $stmt->execute();
  header("Location: courses.php");
  exit();
}


// DELETE Course
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM courses WHERE id=".$_GET['delete']);
    header("Location: courses.php");
    exit();
}

// EDIT MODE
$editData = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editData = $conn->query("SELECT * FROM courses WHERE id=$id")->fetch_assoc();
}

// Fetch data
$courses = $conn->query("SELECT courses.*, departments.name as dept_name, teachers.name as teacher_name 
    FROM courses 
    LEFT JOIN departments ON courses.department_id=departments.id 
    LEFT JOIN teachers ON courses.teacher_id=teachers.id");

$departments = $conn->query("SELECT * FROM departments");
$teachers = $conn->query("SELECT * FROM teachers");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Courses | Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css/coursesCrud.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="AdminDashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li><a href="students.php"><i class="fas fa-users"></i> Manage Students</a></li>
      <li><a href="admin_register_student_course.php"><i class="fas fa-home"></i> Register Student in Course</a></li>
      <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</a></li>
      <li class="active"><a href="courses.php"><i class="fas fa-book"></i> Manage Courses</a></li>
      <li><a href="departments.php"><i class="fas fa-building"></i> Manage Departments</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

  <div class="main-content">
    <div class="header">
      <h1><i class="fas fa-book"></i> Manage Courses</h1>
      <div class="user-info">
        <span>Welcome, <?= $_SESSION['username'] ?></span>
        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username']) ?>&background=random" alt="Profile" class="profile-img">
      </div>
    </div>

    <!-- Add / Update Course Form -->
    <div class="card">
      <h2>
        <?php if($editData){ ?>
          <i class="fas fa-edit"></i> Update Course
        <?php } else { ?>
          <i class="fas fa-plus-circle"></i> Add New Course
        <?php } ?>
      </h2>
      <form method="POST" class="course-form">
        <div class="form-group">
          <label for="name">Course Name</label>
          <input type="text" id="name" name="name" value="<?= $editData ? $editData['name'] : '' ?>" placeholder="Enter course name" required>
        </div>

        <div class="form-group">
          <label for="code">Course Code</label>
          <input type="text" id="code" name="code" value="<?= $editData ? $editData['code'] : '' ?>" placeholder="Enter course code" required>
        </div>

        <div class="form-group">
          <label for="department_id">Department</label>
          <select id="department_id" name="department_id" required>
            <option value="">Select Department</option>
            <?php
              $deptRes = $conn->query("SELECT * FROM departments");
              while($d=$deptRes->fetch_assoc()){
                $selected = ($editData && $editData['department_id']==$d['id']) ? "selected" : "";
                echo "<option value='{$d['id']}' $selected>{$d['name']}</option>";
              }
            ?>
          </select>
        </div>

        <div class="form-group">
          <label for="teacher_id">Assign Teacher</label>
          <select id="teacher_id" name="teacher_id">
            <option value="">Select Teacher</option>
            <?php
              $teachRes = $conn->query("SELECT * FROM teachers");
              while($t=$teachRes->fetch_assoc()){
                $selected = ($editData && $editData['teacher_id']==$t['id']) ? "selected" : "";
                echo "<option value='{$t['id']}' $selected>{$t['name']}</option>";
              }
            ?>
          </select>
        </div>

        <?php if($editData){ ?>
          <input type="hidden" name="id" value="<?= $editData['id'] ?>">
          <button type="submit" name="update_course" class="btn btn-edit">
            <i class="fas fa-save"></i> Update Course
          </button>
          <a href="courses.php" class="btn btn-primary">Cancel</a>
        <?php } else { ?>
          <button type="submit" name="add_course" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Course
          </button>
        <?php } ?>
      </form>
    </div>

    <!-- Courses List -->
    <div class="card">
      <h2><i class="fas fa-list"></i> Course List</h2>
      <div class="table-responsive">
        <table class="styled-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Code</th>
              <th>Department</th>
              <th>Teacher</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while($c=$courses->fetch_assoc()){ ?>
            <tr>
              <td><?= $c['id']?></td>
              <td><?= $c['name']?></td>
              <td><?= $c['code']?></td>
              <td><?= $c['dept_name']?></td>
              <td><?= $c['teacher_name']?></td>
              <td class="actions">
                <a href="?edit=<?= $c['id']?>" class="btn btn-edit"><i class="fas fa-edit"></i> Edit</a>
                <a href="?delete=<?= $c['id']?>" class="btn btn-delete" onclick="return confirm('Delete this course?')">
                  <i class="fas fa-trash-alt"></i> Delete
                </a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
