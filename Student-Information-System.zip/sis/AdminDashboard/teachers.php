<?php
session_start();
include("../config/db.php");
if ($_SESSION['role'] != 'admin') { header("Location: ../index.html"); exit(); }

// ADD teacher
if (isset($_POST['add_teacher'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $dept = $_POST['department_id'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("INSERT INTO teachers (name,email,password,department_id) VALUES (?,?,?,?)");
    $stmt->bind_param("sssi", $name,$email,$password,$dept);
    $stmt->execute();

    header("Location: teachers.php");
    exit();
}

// UPDATE teacher
if (isset($_POST['update_teacher'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $dept = $_POST['department_id'];
    $password = $_POST['password'];

    if (!empty($password)) {
        // Update with new password
        $stmt = $conn->prepare("UPDATE teachers SET name=?, email=?, password=?, department_id=? WHERE id=?");
        $stmt->bind_param("sssii", $name,$email,$password,$dept,$id);
    } else {
        // Update without changing password
        $stmt = $conn->prepare("UPDATE teachers SET name=?, email=?, department_id=? WHERE id=?");
        $stmt->bind_param("ssii", $name,$email,$dept,$id);
    }
    $stmt->execute();

    header("Location: teachers.php");
    exit();
}

// DELETE teacher
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM teachers WHERE id=".$_GET['delete']);
    header("Location: teachers.php");
    exit();
}

// EDIT mode
$editData = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editData = $conn->query("SELECT * FROM teachers WHERE id=$id")->fetch_assoc();
}

// Fetch all teachers and departments
$teachers = $conn->query("SELECT teachers.*, departments.name as dept_name 
    FROM teachers 
    LEFT JOIN departments ON teachers.department_id=departments.id");
$departments = $conn->query("SELECT * FROM departments");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Teachers | Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css/teachersCrud.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="AdminDashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li><a href="students.php"><i class="fas fa-users"></i> Manage Students</a></li>
      <li><a href="admin_register_student_course.php"><i class="fas fa-home"></i> Register Student in Course</a></li>
      <li class="active"><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</a></li>
      <li><a href="courses.php"><i class="fas fa-book"></i> Manage Courses</a></li>
      <li><a href="departments.php"><i class="fas fa-building"></i> Manage Departments</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

  <div class="main-content">
    <div class="header">
      <h1><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</h1>
      <div class="user-info">
        <span>Welcome, <?= $_SESSION['username'] ?></span>
        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username']) ?>&background=random" alt="Profile" class="profile-img">
      </div>
    </div>

    <div class="card">
      <h2>
        <?php if($editData){ ?>
          <i class="fas fa-edit"></i> Update Teacher
        <?php } else { ?>
          <i class="fas fa-plus-circle"></i> Add New Teacher
        <?php } ?>
      </h2>

      <form method="POST" class="teacher-form">
        <div class="form-group">
          <label for="name">Full Name</label>
          <input type="text" id="name" name="name" value="<?= $editData ? $editData['name'] : '' ?>" placeholder="Enter teacher's full name" required>
        </div>
        
        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" value="<?= $editData ? $editData['email'] : '' ?>" placeholder="Enter teacher's email" required>
        </div>
        
        <div class="form-group">
          <label for="password">Password <?= $editData ? '(leave blank to keep unchanged)' : '' ?></label>
          <input type="text" id="password" name="password" value="" placeholder="Enter password">
        </div>
        
        <div class="form-group">
          <label for="department_id">Department</label>
          <select id="department_id" name="department_id" required>
            <option value="">Select Department</option>
            <?php
              $deptRes = $conn->query("SELECT * FROM departments");
              while($d=$deptRes->fetch_assoc()){ 
                $selected = ($editData && $editData['department_id']==$d['id']) ? "selected" : "";
                echo "<option value='{$d['id']}' $selected>{$d['name']}</option>";
              }
            ?>
          </select>
        </div>

        <?php if($editData){ ?>
          <input type="hidden" name="id" value="<?= $editData['id'] ?>">
          <button type="submit" name="update_teacher" class="btn btn-edit">
            <i class="fas fa-save"></i> Update Teacher
          </button>
          <a href="teachers.php" class="btn btn-primary">Cancel</a>
        <?php } else { ?>
          <button type="submit" name="add_teacher" class="btn btn-primary">
            <i class="fas fa-user-plus"></i> Add Teacher
          </button>
        <?php } ?>
      </form>
    </div>

    <div class="card">
      <h2><i class="fas fa-list"></i> Teacher List</h2>
      <div class="table-responsive">
        <table class="styled-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Password</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while($t=$teachers->fetch_assoc()){ ?>
            <tr>
              <td><?= $t['id']?></td>
              <td><?= $t['name']?></td>
              <td><?= $t['email']?></td>
              <td><?= $t['password']?></td>
              <td><?= $t['dept_name']?></td>
              <td class="actions">
                <a href="?edit=<?= $t['id']?>" class="btn btn-edit"><i class="fas fa-edit"></i> Edit</a>
                <a href="?delete=<?= $t['id']?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this teacher?')">
                  <i class="fas fa-trash-alt"></i> Delete
                </a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
