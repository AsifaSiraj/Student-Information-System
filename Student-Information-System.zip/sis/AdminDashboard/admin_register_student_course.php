<?php
session_start();
if ($_SESSION['role'] != 'admin') {
    header("Location: ../index.html");
    exit();
}
include("../config/db.php");

// Handle Registration
if (isset($_POST['register_student'])) {
    $student_id = $_POST['student_id'];
    $course_id  = $_POST['course_id'];

    // Prevent duplicate registration
    $check = $conn->query("SELECT * FROM registrations WHERE student_id=$student_id AND course_id=$course_id");
    if ($check->num_rows == 0) {
        $stmt = $conn->prepare("INSERT INTO registrations (student_id, course_id, registered_by) VALUES (?,?, 'admin')");
        $stmt->bind_param("ii", $student_id, $course_id);
        $stmt->execute();
    }
    header("Location: admin_register_student_course.php");
    exit();
}

// Handle Unregistration (Only Admin)
if (isset($_GET['unregister'])) {
    $reg_id = intval($_GET['unregister']);
    $conn->query("DELETE FROM registrations WHERE id=$reg_id");
    header("Location: admin_register_student_course.php");
    exit();
}

// Fetch all students
$students = $conn->query("SELECT students.*, departments.name as dept_name 
    FROM students 
    LEFT JOIN departments ON students.department_id=departments.id");

// Fetch all courses
$courses = $conn->query("SELECT courses.*, departments.name as dept_name, teachers.name as teacher 
    FROM courses 
    LEFT JOIN departments ON courses.department_id=departments.id 
    LEFT JOIN teachers ON courses.teacher_id=teachers.id");

// Get all registrations (student + admin)
$registrations = $conn->query("SELECT registrations.*, 
        students.name as student_name, students.roll_no,
        courses.name as course_name, courses.code, 
        teachers.name as teacher 
    FROM registrations 
    INNER JOIN students ON registrations.student_id=students.id 
    INNER JOIN courses ON registrations.course_id=courses.id 
    LEFT JOIN teachers ON courses.teacher_id=teachers.id
    ORDER BY registrations.id DESC");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Register Student in Course | Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css/studentsCrud.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="AdminDashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li><a href="students.php"><i class="fas fa-users"></i> Manage Students</a></li>
      <li class="active"><a href="admin_register_student_course.php"><i class="fas fa-user-graduate"></i> Register Student in Course</a></li>
      <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</a></li>
      <li><a href="courses.php"><i class="fas fa-book"></i> Manage Courses</a></li>
      <li><a href="departments.php"><i class="fas fa-building"></i> Manage Departments</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<div class="main-content">
  <div class="header">
    <h1><i class="fas fa-user-graduate"></i> Register Student in Course</h1>
    <div class="user-info">
      <span>Welcome, <?= $_SESSION['username'] ?></span>
      <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username']) ?>&background=random" alt="Profile" class="profile-img">
    </div>
  </div>

  <!-- Assign Form -->
  <div class="card">
    <h2><i class="fas fa-plus-circle"></i> Assign Course to Student</h2>
    <form method="POST" class="student-form">
      <div class="form-group">
        <label for="student_id">Select Student</label>
        <select name="student_id" id="student_id" required>
          <option value="">-- Choose Student --</option>
          <?php while($s=$students->fetch_assoc()){ ?>
            <option value="<?= $s['id']?>"><?= $s['name']?> (<?= $s['roll_no']?>) - <?= $s['dept_name']?></option>
          <?php } ?>
        </select>
      </div>

      <div class="form-group">
        <label for="course_id">Select Course</label>
        <select name="course_id" id="course_id" required>
          <option value="">-- Choose Course --</option>
          <?php while($c=$courses->fetch_assoc()){ ?>
            <option value="<?= $c['id']?>"><?= $c['name']?> (<?= $c['code']?>) - <?= $c['teacher']?> / <?= $c['dept_name']?></option>
          <?php } ?>
        </select>
      </div>

      <button type="submit" name="register_student" class="btn btn-primary">
        <i class="fas fa-check-circle"></i> Register
      </button>
    </form>
  </div>

  <!-- Registered Students List -->
  <div class="card">
    <h2><i class="fas fa-list"></i> All Registrations</h2>
    <div class="table-responsive">
      <table class="styled-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Student</th>
            <th>Roll No</th>
            <th>Course</th>
            <th>Code</th>
            <th>Teacher</th>
            <th>Registered By</th>
            <th>Registered On</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php while($r=$registrations->fetch_assoc()){ ?>
          <tr>
            <td><?= $r['id']?></td>
            <td><?= $r['student_name']?></td>
            <td><?= $r['roll_no']?></td>
            <td><?= $r['course_name']?></td>
            <td><?= $r['code']?></td>
            <td><?= $r['teacher']?></td>
            <td>
              <?php if($r['registered_by']=="admin"){ ?>
                <span class="badge" style="background:#3498db;color:white;padding:4px 8px;border-radius:5px;">Admin</span>
              <?php } else { ?>
                <span class="badge" style="background:#2ecc71;color:white;padding:4px 8px;border-radius:5px;">Student</span>
              <?php } ?>
            </td>
            <td><?= $r['created_at']?></td>
            <td>
              <a href="?unregister=<?= $r['id']?>" 
                 onclick="return confirm('Are you sure you want to unregister this student from the course?')" 
                 class="btn btn-delete">
                 <i class="fas fa-user-slash"></i> Unregister
              </a>
            </td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
