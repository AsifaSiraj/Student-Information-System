<?php
session_start();
if ($_SESSION['role'] != 'admin') {
    header("Location: ../index.html");
    exit();
}
include("../config/db.php");

// Fetch counts
$dept_count = $conn->query("SELECT COUNT(*) as total FROM departments")->fetch_assoc()['total'];
$student_count = $conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total'];
$teacher_count = $conn->query("SELECT COUNT(*) as total FROM teachers")->fetch_assoc()['total'];
$course_count = $conn->query("SELECT COUNT(*) as total FROM courses")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css/AdminDashboard.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
      <li class="active"><a href="AdminDashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li><a href="students.php"><i class="fas fa-users"></i> Manage Students</a></li>
      <li><a href="admin_register_student_course.php"><i class="fas fa-home"></i> Student Course Registration</a></li>
      <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</a></li>
      <li><a href="courses.php"><i class="fas fa-book"></i> Manage Courses</a></li>
      <li><a href="departments.php"><i class="fas fa-building"></i> Manage Departments</a></li>
      <li><a href="admin_register_student_course.php"><i class="fas fa-user-graduate"></i> Register Student in Course</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

  <div class="main-content">
    <div class="header">
      <h1><i class="fas fa-home"></i> Welcome, Admin <?= $_SESSION['username']; ?> 🎉</h1>
      <div class="user-info">
        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username']) ?>&background=random" alt="Profile" class="profile-img">
      </div>
    </div>

    <div class="cards">
      <a href="departments.php" class="card dept">
        <i class="fas fa-building fa-2x"></i>
        <h3>Departments</h3>
        <p><?= $dept_count; ?></p>
      </a>

      <a href="students.php" class="card student">
        <i class="fas fa-users fa-2x"></i>
        <h3>Students</h3>
        <p><?= $student_count; ?></p>
      </a>

      <a href="teachers.php" class="card teacher">
        <i class="fas fa-chalkboard-teacher fa-2x"></i>
        <h3>Teachers</h3>
        <p><?= $teacher_count; ?></p>
      </a>

      <a href="courses.php" class="card course">
        <i class="fas fa-book fa-2x"></i>
        <h3>Courses</h3>
        <p><?= $course_count; ?></p>
      </a>
    </div>
  </div>
</body>
</html>
