<?php 
session_start();
include("../config/db.php");
if ($_SESSION['role'] != 'admin') { header("Location: ../index.html"); exit(); }

// ADD Department
if (isset($_POST['add_department'])) {
    $name = $_POST['name'];
    $stmt = $conn->prepare("INSERT INTO departments (name) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    header("Location: departments.php");
    exit();
}

// UPDATE Department
if (isset($_POST['update_department'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $stmt = $conn->prepare("UPDATE departments SET name=? WHERE id=?");
    $stmt->bind_param("si", $name, $id);
    $stmt->execute();
    header("Location: departments.php");
    exit();
}

// DELETE Department
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM departments WHERE id=".$_GET['delete']);
    header("Location: departments.php");
    exit();
}

// EDIT MODE
$editData = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $editData = $conn->query("SELECT * FROM departments WHERE id=$id")->fetch_assoc();
}

// Fetch all departments
$departments = $conn->query("SELECT * FROM departments");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Departments | Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css/departmentsCrud.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
      <li><a href="AdminDashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li><a href="students.php"><i class="fas fa-users"></i> Manage Students</a></li>
      <li><a href="admin_register_student_course.php"><i class="fas fa-home"></i> Register Student in Course</a></li>
      <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</a></li>
      <li><a href="courses.php"><i class="fas fa-book"></i> Manage Courses</a></li>
      <li  class="active"><a href="departments.php"><i class="fas fa-building"></i> Manage Departments</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

  <div class="main-content">
    <div class="header">
      <h1><i class="fas fa-building"></i> Manage Departments</h1>
      <div class="user-info">
        <span>Welcome, <?= $_SESSION['username'] ?></span>
        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username']) ?>&background=random" alt="Profile" class="profile-img">
      </div>
    </div>

    <!-- Add / Update Department Form -->
    <div class="card">
      <h2>
        <?php if($editData){ ?>
          <i class="fas fa-edit"></i> Update Department
        <?php } else { ?>
          <i class="fas fa-plus-circle"></i> Add New Department
        <?php } ?>
      </h2>
      <form method="POST" class="dept-form">
        <div class="form-group">
          <label for="name">Department Name</label>
          <input type="text" id="name" name="name" value="<?= $editData ? $editData['name'] : '' ?>" placeholder="Enter department name" required>
        </div>
        <?php if($editData){ ?>
          <input type="hidden" name="id" value="<?= $editData['id'] ?>">
          <button type="submit" name="update_department" class="btn btn-edit">
            <i class="fas fa-save"></i> Update Department
          </button>
          <a href="departments.php" class="btn btn-primary">Cancel</a>
        <?php } else { ?>
          <button type="submit" name="add_department" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Department
          </button>
        <?php } ?>
      </form>
    </div>

    <!-- Department List -->
    <div class="card">
      <h2><i class="fas fa-list"></i> Department List</h2>
      <div class="table-responsive">
        <table class="styled-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while($d=$departments->fetch_assoc()){ ?>
            <tr>
              <td><?= $d['id']?></td>
              <td><?= $d['name']?></td>
              <td class="actions">
                <a href="?edit=<?= $d['id']?>" class="btn btn-edit"><i class="fas fa-edit"></i> Edit</a>
                <a href="?delete=<?= $d['id']?>" class="btn btn-delete" onclick="return confirm('Delete this department?')">
                  <i class="fas fa-trash-alt"></i> Delete
                </a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
