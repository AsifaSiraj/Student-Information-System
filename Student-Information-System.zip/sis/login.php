<?php
session_start();
include("config/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // 1. Check in users table (admins only)
    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();

    if ($user && $user['password'] === $password) { // plain check
        $_SESSION['role'] = $user['role'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['id'] = $user['id'];

        if ($user['role'] == "admin") {
            header("Location: AdminDashboard/AdminDashboard.php"); 
            exit();
        }
    }

    // 2. Check in teachers table (username = email)
    $stmt = $conn->prepare("SELECT * FROM teachers WHERE email=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();
    $teacher = $res->fetch_assoc();

    if ($teacher && $teacher['password'] === $password) { // plain check
        $_SESSION['role'] = "teacher";
        $_SESSION['username'] = $teacher['name'];
        $_SESSION['id'] = $teacher['id'];

        header("Location: dashboard/teacher.php");
        exit();
    }

    // 3. Check in students table (username = email OR roll_no)
    $stmt = $conn->prepare("SELECT * FROM students WHERE email=? OR roll_no=?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $res = $stmt->get_result();
    $student = $res->fetch_assoc();

    if ($student && $student['password'] === $password) { // plain check
        $_SESSION['role'] = "student";
        $_SESSION['username'] = $student['name'];
        $_SESSION['id'] = $student['id'];

        header("Location: dashboard/student.php");
        exit();
    }

    // If nothing matched
    echo "<script>alert('Invalid credentials!'); window.location='index.html';</script>";
}
?>
