<?php
$host = "localhost";       // Database host
$user = "root";            // MySQL username (default in XAMPP/WAMP is "root")
$pass = "";                // MySQL password (default is empty in XAMPP/WAMP)
$dbname = "student_info_system";  // Database name

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection failed: " . $conn->connect_error);
}
?>
