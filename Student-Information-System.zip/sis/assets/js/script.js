// Simple interactivity example
document.addEventListener("DOMContentLoaded", () => {
    const tables = document.querySelectorAll("table");
    tables.forEach(tbl => {
      tbl.style.borderCollapse = "collapse";
    });
  
    const buttons = document.querySelectorAll("button");
    buttons.forEach(btn => {
      btn.addEventListener("mouseover", () => btn.style.opacity = "0.8");
      btn.addEventListener("mouseout", () => btn.style.opacity = "1");
    });
  });
  