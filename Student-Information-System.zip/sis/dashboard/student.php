<?php
session_start();
if ($_SESSION['role'] != 'student') {
    header("Location: ../index.html");
    exit();
}
include("../config/db.php");

// Get student info
$username = $_SESSION['username'];
$student = $conn->query("SELECT * FROM students WHERE email='$username' OR name='$username'")->fetch_assoc();
$student_id = $student['id'];

// Register in a course
if (isset($_POST['register_course'])) {
    $course_id = $_POST['course_id'];

    // Check if already registered
    $check = $conn->query("SELECT * FROM registrations WHERE student_id=$student_id AND course_id=$course_id");
    if ($check->num_rows == 0) {
        $conn->query("INSERT INTO registrations (student_id,course_id) VALUES ($student_id,$course_id)");
    }
    header("Location: student.php");
    exit();
}

// Get all courses in student's department
$courses = $conn->query("SELECT courses.*, teachers.name as teacher 
    FROM courses 
    LEFT JOIN teachers ON courses.teacher_id=teachers.id 
    WHERE courses.department_id=".$student['department_id']);

// Get registered courses
$myCourses = $conn->query("SELECT courses.*, teachers.name as teacher 
    FROM registrations 
    INNER JOIN courses ON registrations.course_id=courses.id 
    LEFT JOIN teachers ON courses.teacher_id=teachers.id 
    WHERE registrations.student_id=$student_id");

// Count total stats
$totalCourses = $conn->query("SELECT COUNT(*) as c FROM courses WHERE department_id=".$student['department_id'])->fetch_assoc()['c'];
$totalStudents = $conn->query("SELECT COUNT(*) as s FROM students WHERE department_id=".$student['department_id'])->fetch_assoc()['s'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="../assets/css/StudentDashboard.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Student Panel</h2>
    <ul>
      <li class="active"><a href="student.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<div class="main-content">
  <div class="header">
    <h1><i class="fas fa-user-graduate"></i> Welcome, <?= $student['name'] ?></h1>
    <div class="user-info">
      <span>Student</span>
      <img src="https://ui-avatars.com/api/?name=<?= urlencode($student['name']) ?>&background=random" class="profile-img">
    </div>
  </div>

  <!-- Stats -->
  <div class="stats">
    <div class="stat-card">
      <i class="fas fa-book"></i>
      <h3><?= $totalCourses ?></h3>
      <p>Total Courses</p>
    </div>
    <div class="stat-card">
      <i class="fas fa-users"></i>
      <h3><?= $totalStudents ?></h3>
      <p>Total Students in Dept</p>
    </div>
  </div>

  <!-- Register New Course -->
  <div class="card">
    <h2><i class="fas fa-plus-circle"></i> Register in a Course</h2>
    <form method="POST" class="course-form">
      <select name="course_id" required>
        <option value="">Select Course</option>
        <?php while($c=$courses->fetch_assoc()){ ?>
          <option value="<?= $c['id']?>"><?= $c['name']?> (<?= $c['code']?>) - <?= $c['teacher']?></option>
        <?php } ?>
      </select>
      <button type="submit" name="register_course" class="btn btn-primary">
        <i class="fas fa-check-circle"></i> Register
      </button>
    </form>
  </div>

  <!-- My Registered Courses -->
  <div class="card">
    <h2><i class="fas fa-list"></i> My Registered Courses</h2>
    <div class="table-responsive">
      <table class="styled-table">
        <thead>
          <tr>
            <th>Course</th>
            <th>Code</th>
            <th>Teacher</th>
            <th>Total Students Enrolled</th>
          </tr>
        </thead>
        <tbody>
          <?php while($mc=$myCourses->fetch_assoc()){ 
            $count = $conn->query("SELECT COUNT(*) as c FROM registrations WHERE course_id=".$mc['id'])->fetch_assoc()['c'];
          ?>
          <tr>
            <td><?= $mc['name']?></td>
            <td><?= $mc['code']?></td>
            <td><?= $mc['teacher']?></td>
            <td><?= $count ?></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
