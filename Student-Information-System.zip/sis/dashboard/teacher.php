<?php
session_start();
if ($_SESSION['role'] != 'teacher') {
    header("Location: ../index.html");
    exit();
}
include("../config/db.php");

// Get teacher info
$username = $_SESSION['username'];
$teacher = $conn->query("SELECT * FROM teachers WHERE email='$username' OR name='$username'")->fetch_assoc();
$teacher_id = $teacher['id'];

// Teacher self-assign to a course
if (isset($_POST['register_course'])) {
    $course_id = $_POST['course_id'];

    // Check if course is unassigned
    $check = $conn->query("SELECT teacher_id FROM courses WHERE id=$course_id")->fetch_assoc();
    if (empty($check['teacher_id'])) {
        $conn->query("UPDATE courses SET teacher_id=$teacher_id WHERE id=$course_id");

        // Log this action (optional)
        $conn->query("INSERT INTO teacher_course_logs (teacher_id, course_id, action) 
                      VALUES ($teacher_id, $course_id, 'self_registered')");
    }

    header("Location: teacher.php");
    exit();
}

// Courses already assigned to this teacher
$courses = $conn->query("SELECT * FROM courses WHERE teacher_id=$teacher_id");

// Unassigned courses (for teacher to claim)
$availableCourses = $conn->query("SELECT * FROM courses WHERE teacher_id IS NULL");

// Stats
$totalStudents = $conn->query("SELECT COUNT(*) as s 
    FROM registrations 
    INNER JOIN courses ON registrations.course_id=courses.id 
    WHERE courses.teacher_id=$teacher_id")->fetch_assoc()['s'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Teacher Dashboard</title>
  <link rel="stylesheet" href="../assets/css/teachersDashboard.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="sidebar">
    <h2>Teacher Panel</h2>
    <ul>
      <li class="active"><a href="teacher.php"><i class="fas fa-home"></i> Dashboard</a></li>
      <li><a href="../index.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<div class="main-content">
  <div class="header">
    <h1><i class="fas fa-chalkboard-teacher"></i> Welcome, <?= $teacher['name'] ?></h1>
    <div class="user-info">
      <span>Teacher</span>
      <img src="https://ui-avatars.com/api/?name=<?= urlencode($teacher['name']) ?>&background=random" class="profile-img">
    </div>
  </div>

  <!-- Stats -->
  <div class="stats">
    <div class="stat-card">
      <i class="fas fa-book"></i>
      <h3><?= $courses->num_rows ?></h3>
      <p>Courses You Teach</p>
    </div>
    <div class="stat-card">
      <i class="fas fa-users"></i>
      <h3><?= $totalStudents ?></h3>
      <p>Total Students Enrolled</p>
    </div>
  </div>

  <!-- Register in a New Course -->
  <div class="card">
    <h2><i class="fas fa-plus-circle"></i> Register Yourself in a New Course</h2>
    <form method="POST" class="course-form">
      <select name="course_id" required>
        <option value="">Select Available Course</option>
        <?php while($ac=$availableCourses->fetch_assoc()){ ?>
          <option value="<?= $ac['id']?>"><?= $ac['name']?> (<?= $ac['code']?>)</option>
        <?php } ?>
      </select>
      <button type="submit" name="register_course" class="btn btn-primary">
        <i class="fas fa-check-circle"></i> Register
      </button>
    </form>
  </div>

  <!-- My Courses -->
  <div class="card">
    <h2><i class="fas fa-list"></i> Courses You Teach</h2>
    <div class="table-responsive">
      <table class="styled-table">
        <thead>
          <tr>
            <th>Course</th>
            <th>Code</th>
            <th>Total Students</th>
            <th>Enrolled Students</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          mysqli_data_seek($courses, 0); // reset pointer
          while($c=$courses->fetch_assoc()){ 
            $count = $conn->query("SELECT COUNT(*) as c FROM registrations WHERE course_id=".$c['id'])->fetch_assoc()['c'];
            $students = $conn->query("SELECT students.name 
                                      FROM registrations 
                                      INNER JOIN students ON registrations.student_id=students.id 
                                      WHERE registrations.course_id=".$c['id']);
          ?>
          <tr>
            <td><?= $c['name']?></td>
            <td><?= $c['code']?></td>
            <td><?= $count ?></td>
            <td>
              <?php if ($count > 0) { ?>
              <ul>
                <?php while($s=$students->fetch_assoc()){ ?>
                  <li><?= $s['name']?></li>
                <?php } ?>
              </ul>
              <?php } else { ?>
                <span style="color:gray">No students yet</span>
              <?php } ?>
            </td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
